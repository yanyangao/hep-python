void rootlogon()
{
  // Load ATLAS style
  gROOT->LoadMacro("AtlasStyle.C");
  SetAtlasStyle();
}
